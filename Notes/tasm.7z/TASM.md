Базовая информация о турбо ассемблере x8086
## Basics
![[Basics#Turbo assembler x8086]]

___
## Data allocation
![[Data allocation]]

___
## Registers
![[Registers]]
___
## Programs
[[Programs]]
___
## Operators
![[Operators]]

## Процедуры
![[Процедуры]]

## Ассемблерная вставка
![[Ассемблерная вставка]]