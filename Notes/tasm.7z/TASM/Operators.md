## Прерывания
![[Прерывания#Description]]
## Work with data
[[Work with data]]
Operators:
- [[Work with data#mov|mov]]
- [[Work with data#[] - Квадратные скобки|[] - Квадратные скобки]]
- [[Work with data#xchg|xchg]]
- [[Work with data#offset|offest]]
- [[Work with data#lea|lea]]
- [[Work with data#PTR (указатели на данные)|Указатели на данные]]
- [[Work with data#push & pop|Stack]]
- [[Work with data#cwd|cwd]]

## Work with numbers
[[Work with numbers]]
Operators:
- [[Work with numbers#add (addition)|add]]
- [[Work with numbers#sub (substitution)|sub]]
- [[Work with numbers#inc (increment)|inc]]
- [[Work with numbers#dec (decrement)|dec]]
- [[Work with numbers#mul|mul]]
- [[Work with numbers#imul (integer multilpy)|imul]]
- [[Work with numbers#div|div]]
- [[Work with numbers#idiv (integer divide)|idiv]]
## Loops and jumps
![[Loops and Jumps#Loop]]
##### [[Loops and Jumps#^9800cc|Команды LOOPE/LOOPZ и LOOPNE/LOOPNZ]]
![[Loops and Jumps#Unconditional jump]]
#### Conditional jumps
![[Loops and Jumps#^424332]]
Conditions:
[[Loops and Jumps#^d87010|signed data conditional jumps]]
[[Loops and Jumps#^364ec5|unsigned data conditional jumps]]
[[Loops and Jumps#^ee4881|special conditional jumps]]

## Logical instructions
![[Logical instructions]]
## Bitwise operations
![[Bitwise operations]]
